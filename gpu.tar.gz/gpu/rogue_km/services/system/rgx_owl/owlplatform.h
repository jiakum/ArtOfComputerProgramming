#if !defined(OWL_PLATFORM_H_)
#define OWL_PLATFORM_H_

#include <linux/device.h>

int owl_gpu_init(struct device *dev);
void owl_gpu_uninit(void);

int owl_gpu_set_power_enable(bool enabled);
int owl_gpu_set_clock_enable(bool enabled);

unsigned long owl_gpu_get_clock_speed(void);

#endif /* #define OWL_PLATFORM_H_ */
