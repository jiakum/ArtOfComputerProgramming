#include <linux/clk.h>
#include <linux/regulator/consumer.h>
#include <linux/atomic.h>
#include <linux/io.h>
#include <linux/delay.h>

#include "owlfreq.h"
#include "syslocal.h"

struct owl_regulator {
	struct regulator *regulator;
	char *name;
};

struct owl_clk {
	struct clk *clk;
	char *name;
};

static struct owl_regulator gpu_regulator = { .name = "gpu" };

static struct owl_clk gpu_clk      = { .name = "gpu" };
static struct owl_clk gpu_core_clk = { .name = "gpu_core" };
static struct owl_clk gpu_mem_clk  = { .name = "gpu_mem" };
static struct owl_clk gpu_sys_clk  = { .name = "gpu_sys" };

static struct owl_clk dev_clk      = { .name = "dev_clk" };
static struct owl_clk display_pll  = { .name = "display_pll" };

static struct gpufreq_entry gpu_freq_table[] = {
	{ 220000000,  810000,  0,  90, &dev_clk },
	{ 330000000,  940000, 55,  90, &dev_clk },
	{ 528000000,  940000, 53, 100, &display_pll },
//	{ 528000000, 1000000, 53, 100, &display_pll },
};

#define VOLTAGE_BIAS 10000
#define NUM_ENTRY_OF_FREQTABLE ARRAY_SIZE(gpu_freq_table)

/******************************************************************************************************
 * Basic voltage and clock function.
 *****************************************************************************************************/
static int getVoltage(void)
{
	return regulator_get_voltage(gpu_regulator.regulator);
}

static int setVoltage(int min_uV, int max_uV)
{
	int err = regulator_set_voltage(gpu_regulator.regulator, min_uV, max_uV);
	if (err)
		pr_err("Failed to set gpu power voltage!\n");

	return err;
}

static int enablePower(void)
{
	int err = 0;
	if (!regulator_is_enabled(gpu_regulator.regulator)) {
		err = regulator_enable(gpu_regulator.regulator);
		if (err)
			pr_err("Failed to enable gpu power supply!\n");
	}

	return err;
}

static int disablePower(void)
{
	int err = 0;
	if (regulator_is_enabled(gpu_regulator.regulator))
		err = regulator_disable(gpu_regulator.regulator);

	return err;
}

static unsigned long getClockRate(void)
{
	return clk_get_rate(gpu_core_clk.clk);
}

static int setClockRate(struct owl_clk *gpu_parent_clk, unsigned long rate)
{
	int err;

	err  = clk_set_parent(gpu_core_clk.clk, gpu_parent_clk->clk);
	err |= clk_set_parent(gpu_mem_clk.clk,  gpu_parent_clk->clk);
	err |= clk_set_parent(gpu_sys_clk.clk,  gpu_parent_clk->clk);

	if (err) {
		pr_err("Failed to set gpu parent clock %s\n", gpu_parent_clk->name);
		return err;
	}

	err = (clk_set_rate(gpu_core_clk.clk, rate) ||
		   clk_set_rate(gpu_mem_clk.clk,  rate) ||
		   clk_set_rate(gpu_sys_clk.clk,  rate));

	if (err) {
		pr_err("Failed to set gpu clock rate %lu\n", rate);
		return err;
	}

	return err;
}

static int validateFreqTable(bool correct, struct gpufreq_entry freqtable[], int size)
{
	int err, i;
	long rate;
	struct owl_clk *parent_clk;
	for (i = 0; i < size; i++) {
		parent_clk = (struct owl_clk *)freqtable[i].pdata;
		err = clk_set_parent(gpu_core_clk.clk, parent_clk->clk);
		if (err) {
			pr_err("Failed to set gpu parent clock %s\n", parent_clk->name);
			return err;
		}

		rate = clk_round_rate(gpu_core_clk.clk, freqtable[i].freq);
		if (rate < 0) {
			pr_err("clk_round_rate error\n");
			return -1;
		}

		if (rate != freqtable[i].freq) {
			pr_warning("[GPU] request clock rate %lu, but return %lu (parent=%s)\n",
					   freqtable[i].freq, rate, parent_clk->name);
			if (correct) {
				freqtable[i].freq = rate;
				if (i > 0) {
					int threshold = freqtable[i - 1].max_threshold * freqtable[i - 1].freq / freqtable[i].freq;
					if (freqtable[i].min_threshold >= threshold)
						freqtable[i].min_threshold = threshold - 1;
				}
			}
		}
	}

	return 0;
}

static int enableClock(void)
{
	int err;
	err = (clk_prepare_enable(gpu_clk.clk)||
		   clk_prepare_enable(gpu_core_clk.clk) ||
		   clk_prepare_enable(gpu_mem_clk.clk)  ||
		   clk_prepare_enable(gpu_sys_clk.clk));
	if (err)
		pr_err("Failed to enable gpu clock!\n");

	return err;
}

static void disableClock(void)
{
	clk_disable_unprepare(gpu_clk.clk);
	clk_disable_unprepare(gpu_core_clk.clk);
	clk_disable_unprepare(gpu_mem_clk.clk);
	clk_disable_unprepare(gpu_sys_clk.clk);
}

/******************************************************************************************************
 * Setup clock and voltage.
 *****************************************************************************************************/
static atomic_t clock_en = { 0 };
static atomic_t power_en = { 0 };

static int owl_clock_is_enabled(void) {
	return atomic_read(&clock_en);
}

static int owl_power_is_enabled(void)
{
	return atomic_read(&power_en);
}

static int owl_set_clockenabled(int enabled)
{
	int err = 0;
	if (enabled) {
		if (!atomic_read(&clock_en)) {
			err = enableClock();
			atomic_set(&clock_en, !err);
		}
	} else {
		if (atomic_read(&clock_en)) {
			disableClock();
			atomic_set(&clock_en, 0);
		}
	}

	return err;
}

static int owl_set_powerenabled(int enabled)
{
	int err = 0;
	if (enabled) {
		if (!atomic_read(&power_en)) {
			err = enablePower();
			atomic_set(&power_en, !err);
		}
	} else {
		if (atomic_read(&power_en)) {
			err = disablePower();
			atomic_set(&power_en, err);
		}
	}

	return err;
}

static int owl_get_freqtable(struct gpufreq_entry **freqtable)
{
	*freqtable = gpu_freq_table;
	return NUM_ENTRY_OF_FREQTABLE;
}

/* Device should be idle when changing frequency. */
static int owl_set_clocklevel(int level)
{
	int err = -1; 
	if (level >= 0 && level < NUM_ENTRY_OF_FREQTABLE) {
		int oldvol = getVoltage();
		int newvol = gpu_freq_table[level].vol;
		if (newvol < oldvol) {
			err  = setClockRate((struct owl_clk *)gpu_freq_table[level].pdata,
								gpu_freq_table[level].freq);
			err |= setVoltage(newvol - VOLTAGE_BIAS, newvol + VOLTAGE_BIAS);
		} else {
			err  = setVoltage(newvol - VOLTAGE_BIAS, newvol + VOLTAGE_BIAS);
			err |= setClockRate((struct owl_clk *)gpu_freq_table[level].pdata,
								gpu_freq_table[level].freq);
		}
	}

	return err;
}

static unsigned long owl_get_clockspeed(int level)
{
	return gpu_freq_table[level].freq;
}

static unsigned long owl_get_current_clockspeed(void)
{
	return getClockRate();
}

// relation: 1 higher >=, 0 lower <=
static int owl_match_clocklevel(unsigned long freq, int relation)
{
	int i;
	for (i = 0; i < NUM_ENTRY_OF_FREQTABLE; i++) {
		if (freq <= gpu_freq_table[i].freq)
			break;
	}

	if (i == NUM_ENTRY_OF_FREQTABLE)
		return NUM_ENTRY_OF_FREQTABLE - 1;
	else if (i == 0 || freq == gpu_freq_table[i].freq)
		return i;
	else if (relation == RELATION_H)
		return i;
	else
		return i - 1;
}

static int owl_match_vollevel(int vol, int relation)
{
	int i;
	for (i = 0; i < NUM_ENTRY_OF_FREQTABLE; i++) {
		if (vol <= gpu_freq_table[i].vol)
			break;
	}

	if (i == NUM_ENTRY_OF_FREQTABLE)
		return NUM_ENTRY_OF_FREQTABLE - 1;
	else if (i == 0 || vol == gpu_freq_table[i].vol)
		return i;
	else if (relation == RELATION_H)
		return i;
	else
		return i - 1;
}

static int owl_gpu_freq_init(void)
{
	gpu_regulator.regulator = devm_regulator_get(&gpsPVRLDMDev->dev, gpu_regulator.name);
	if (IS_ERR(gpu_regulator.regulator)) {
		pr_err("Failed to get gpu regulator\n");
		return -ENODEV;
	}

	gpu_clk.clk      = devm_clk_get(&gpsPVRLDMDev->dev, gpu_clk.name);
	gpu_core_clk.clk = devm_clk_get(&gpsPVRLDMDev->dev, gpu_core_clk.name);
	gpu_mem_clk.clk  = devm_clk_get(&gpsPVRLDMDev->dev, gpu_mem_clk.name);
	gpu_sys_clk.clk  = devm_clk_get(&gpsPVRLDMDev->dev, gpu_sys_clk.name);
	if (IS_ERR(gpu_clk.clk) ||
		IS_ERR(gpu_core_clk.clk) ||
		IS_ERR(gpu_mem_clk.clk) ||
		IS_ERR(gpu_sys_clk.clk)) {
		pr_err("Failed to get gpu clock\n");
		return -ENODEV;
	}

	dev_clk.clk = clk_get(NULL, dev_clk.name);
	if (IS_ERR(dev_clk.clk)) {
		pr_err("Failed to get dev_clk\n");
		return -ENODEV;
	}

	display_pll.clk = clk_get(NULL, display_pll.name);
	if (IS_ERR(display_pll.clk)) {
		pr_err("Failed to get display_pll\n");
		return -ENODEV;
	}

	/** validate the frequency table. */
	if (validateFreqTable(true, gpu_freq_table, NUM_ENTRY_OF_FREQTABLE)) {
		pr_err("Failed to validate gpu frequency table\n");
		return -ENODEV;
	}

	return 0;
}

static void owl_gpu_freq_deinit(void)
{
	clk_put(dev_clk.clk);
	clk_put(display_pll.clk);
}

struct gpufreq_driver owl_gpufreq_driver = {
	.init = owl_gpu_freq_init,
	.uninit = owl_gpu_freq_deinit,
	.clock_is_enabled = owl_clock_is_enabled,
	.power_is_enabled = owl_power_is_enabled,
	.set_clockstat = owl_set_clockenabled,
	.set_powerstat = owl_set_powerenabled,
	.get_freqtable = owl_get_freqtable,
	.get_current_clockspeed = owl_get_current_clockspeed,
	.get_clockspeed   = owl_get_clockspeed,
	.set_clockspeed   = owl_set_clocklevel,
	.get_matchlevel   = owl_match_clocklevel,
	.get_matchvollevel = owl_match_vollevel,
};

