#if !defined(OWL_DVFS_H_)
#define OWL_DVFS_H_

#include <linux/types.h>

//#define SUPPORT_GPU_DVFS

int register_gpufreq_dvfs(int level);
int unregister_gpufreq_dvfs(void);

int gpu_dvfs_is_enabled(void);

#if defined(SUPPORT_GPU_DVFS)
int gpu_dvfs_enable(void);
void gpu_dvfs_disable(void);
#endif

int gpu_dvfs_get_freqtable(char *buf, size_t *buf_size);
int gpu_dvfs_get_utilisation(void);

int gpu_dvfs_get_level(void);
unsigned long gpu_dvfs_get_clock(int level);
int gpu_dvfs_set_level_range(int minlevel, int maxlevel);

static inline int gpu_dvfs_set_level(int level)
{
	return gpu_dvfs_set_level_range(level, level);
}

#endif /* #if !defined(OWL_DVFS_H_) */
