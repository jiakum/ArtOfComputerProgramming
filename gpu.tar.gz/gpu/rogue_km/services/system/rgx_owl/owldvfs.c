#include <linux/kernel.h>
#include <linux/workqueue.h>
#include <linux/hrtimer.h>
#include <asm/atomic.h>
#include <linux/rwsem.h>
#include <linux/mutex.h>

#include "syslocal.h"
#include "owldvfs.h"
#include "owlfreq.h"

/* Conversion helpers for setting up high resolution timers */
#define HR_TIMER_DELAY_MSEC(x) (ns_to_ktime(((u64)(x))*1000000UL))
#define HR_TIMER_DELAY_NSEC(x) (ns_to_ktime(x))

typedef void (*timer_callback_func)(void*);
struct gpudvfs_timer
{
	atomic_t      		bActive;

    struct 				hrtimer sTimer;
    u32			        ui32Delay;
    ktime_t             ktime;

    timer_callback_func pfnTimerFunc;
    void 			   *pvData;

	struct workqueue_struct *psWorkQueue;
    struct work_struct	sWork;
};

struct gpufreq_dvfs
{
	/* dvfs enabled. */
	atomic_t bEnable;
	struct gpu_util *psUtil;

	int level;
	int max_level_lock;
	int min_level_lock;
#if defined(CONFIG_OWL_THERMAL)
	int thermal_level_lock;
#endif

	gpufreq_entry_t *dvfs_table;
	int num_freqtable_entry;

	struct rw_semaphore dvfs_rwsem;
	struct mutex dvfs_enable_mutex;

	struct gpufreq_driver *driver;
	struct gpudvfs_timer sTimerCallback;

	int (*preClockSpeedChange)(int bIdle);
	int (*postClockSpeedChange)(int bIdle);
};

static struct gpu_util gpuutil = {
	.bValid = 0,	
	.active = 100,
	.blocked = 0,
	.idle    = 0,
};

static struct gpufreq_dvfs gpudvfs = {
	.driver = &owl_gpufreq_driver,
	.psUtil = &gpuutil,
};

static int set_level(int level);

static inline int dvfs_rwsem_down_read(void)
{
	down_read(&gpudvfs.dvfs_rwsem);
	return 0;
}

static inline void dvfs_rwsem_up_read(void)
{
	up_read(&gpudvfs.dvfs_rwsem);
}

static inline int dvfs_rwsem_down_write(void)
{
	down_write(&gpudvfs.dvfs_rwsem);
	return 0;
}

static inline void dvfs_rwsem_up_write(void)
{
	up_write(&gpudvfs.dvfs_rwsem);
}

#if defined(SUPPORT_GPU_DVFS)

static enum hrtimer_restart dvfs_timer_callback_wrapper(struct hrtimer *psTimer)
{
	int res;
    struct gpudvfs_timer *psTimerCB = container_of(psTimer, struct gpudvfs_timer, sTimer);

    psTimerCB->ktime = psTimer->base->get_time();

    res = queue_work(psTimerCB->psWorkQueue, &psTimerCB->sWork);
	if (res == 0)
		pr_debug("GPU: dvfs_timer_callback_wrapper: work already queued\n");

	if (atomic_read(&psTimerCB->bActive)) {
		hrtimer_forward(&psTimerCB->sTimer, psTimerCB->ktime, HR_TIMER_DELAY_MSEC(psTimerCB->ui32Delay));
		return HRTIMER_RESTART;
	} else {
		return HRTIMER_NORESTART;
	}
}

static void dvfs_timer_workqueue_callback(struct work_struct *psWork)
{
    struct gpudvfs_timer *psTimerCB = container_of(psWork, struct gpudvfs_timer, sWork);

	if (!atomic_read(&psTimerCB->bActive))
        return;

    /* call timer callback */
    psTimerCB->pfnTimerFunc(psTimerCB->pvData);
}

static int dvfs_timer_init(struct gpudvfs_timer *psTimerCB,
		timer_callback_func pfnTimerFunc, void *pvData, u32 ui32MsTimeout)
{
	atomic_set(&psTimerCB->bActive, 0);

	psTimerCB->pfnTimerFunc = pfnTimerFunc;
	psTimerCB->pvData = pvData;

    hrtimer_init(&psTimerCB->sTimer, CLOCK_MONOTONIC, HRTIMER_MODE_REL);
    psTimerCB->sTimer.function = (void *)dvfs_timer_callback_wrapper;
    psTimerCB->ui32Delay = ui32MsTimeout;

	psTimerCB->psWorkQueue = create_workqueue("gpu_dvfs_workqueue");
	INIT_WORK(&psTimerCB->sWork, dvfs_timer_workqueue_callback);

	return 0;
}

static int dvfs_timer_deinit(struct gpudvfs_timer *psTimerCB)
{
	destroy_workqueue(psTimerCB->psWorkQueue);
	return 0;
}

static int dvfs_timer_enable(struct gpudvfs_timer *psTimerCB)
{
	int ret;

	if (atomic_read(&psTimerCB->bActive))
		return 0;

	ret = hrtimer_start(&psTimerCB->sTimer,
						HR_TIMER_DELAY_MSEC(psTimerCB->ui32Delay),
						HRTIMER_MODE_REL);

	if (!ret) {
		atomic_set(&psTimerCB->bActive, 1);
	}

    return ret;
}

static int dvfs_timer_disable (struct gpudvfs_timer *psTimerCB)
{
	if (!atomic_read(&psTimerCB->bActive))
		return 0;

    /* Stop timer from arming */
    atomic_set(&psTimerCB->bActive, 0);
    smp_mb();

    flush_workqueue(psTimerCB->psWorkQueue);

	hrtimer_cancel(&psTimerCB->sTimer);

    /*
     * This second flush is to catch the case where the timer ran
     * before we managed to delete it, in which case, it will have
     * queued more work for the workqueue.  Since the bActive flag
     * has been cleared, this second flush won't result in the
     * timer being rearmed.
     */
    flush_workqueue(psTimerCB->psWorkQueue);

    return 0;
}

static unsigned long get_clock(void)
{
	return gpudvfs.dvfs_table[gpudvfs.level].freq;
}

static int dvfs_decide_next_level(struct gpu_util *psUtil)
{
	int level = gpudvfs.level;
	int load = psUtil->active;
	if (load > gpudvfs.dvfs_table[level].max_threshold) {
		level++;
	} else if (load < gpudvfs.dvfs_table[level].min_threshold) {
		level--;
	}

	/* Frequency lock. */
	if (level > gpudvfs.max_level_lock)
		level = gpudvfs.max_level_lock;
	else if (level < gpudvfs.min_level_lock)
		level = gpudvfs.min_level_lock;

#if defined(CONFIG_OWL_THERMAL)
	if (level > gpudvfs.thermal_level_lock)
		level = gpudvfs.thermal_level_lock;
#endif

	return level;
}

static void dvfs_proc_func(void * pvData)
{
	struct gpu_util *psUtil = gpudvfs.psUtil;

	dvfs_rwsem_down_write();

	OwlRGXGetUtilStats(psUtil);
	if (psUtil->bValid) {
		int level = dvfs_decide_next_level(psUtil);

		if (level != gpudvfs.level) {
			int err = set_level(level);
			if (err)
				pr_warning("GPU: %s: fail to set dvfs level %d\n", __func__, level);

			pr_debug("GPU: dvfs(%lld ms): load %3u, freq -> %9lu\n",
					 ktime_to_ns(((struct gpudvfs_timer *)pvData)->ktime) / 1000000u,
					 psUtil->active, get_clock());
		}
	}

	dvfs_rwsem_up_write();
}

static int dvfs_init(int dvfs_window_ms)
{
	gpudvfs.psUtil->window_size_ms = dvfs_window_ms;
	return dvfs_timer_init(&gpudvfs.sTimerCallback, dvfs_proc_func,
						   &gpudvfs.sTimerCallback,
						   dvfs_window_ms);
}

static void dvfs_deinit(void)
{
	gpu_dvfs_disable();
	dvfs_timer_deinit(&gpudvfs.sTimerCallback);
}

static int dvfs_enable(void)
{
	int ret;
	if (atomic_read(&gpudvfs.bEnable))
		return 0;

	ret = dvfs_timer_enable(&gpudvfs.sTimerCallback);

	if (!ret)
		atomic_set(&gpudvfs.bEnable, 1);

	return ret;
}

static void dvfs_disable(void)
{
	if (!atomic_read(&gpudvfs.bEnable))
		return;

	dvfs_timer_disable(&gpudvfs.sTimerCallback);
	atomic_set(&gpudvfs.bEnable, 0);
}

int gpu_dvfs_enable(void)
{
	int ret = -1;

	mutex_lock(&gpudvfs.dvfs_enable_mutex);

	if (gpudvfs.min_level_lock < gpudvfs.max_level_lock)
		ret = dvfs_enable();

	mutex_unlock(&gpudvfs.dvfs_enable_mutex);

	return ret;
}

void gpu_dvfs_disable(void)
{
	mutex_lock(&gpudvfs.dvfs_enable_mutex);

	dvfs_disable();

	mutex_unlock(&gpudvfs.dvfs_enable_mutex);
}

#endif /* defined(SUPPORT_GPU_DVFS) */

int gpu_dvfs_is_enabled(void)
{
	return atomic_read(&gpudvfs.bEnable);
}

int gpu_dvfs_get_freqtable(char *buf, size_t *buf_size)
{
	int i, cnt = 0;
	if (buf == NULL)
		goto exit_out;

	for (i = 0; i < gpudvfs.num_freqtable_entry; i++)
		cnt += snprintf(buf+cnt, *buf_size - cnt, "%lu\n", gpudvfs.dvfs_table[i].freq);

	*buf_size = cnt;

exit_out:
	return gpudvfs.num_freqtable_entry;
}

int gpu_dvfs_get_utilisation(void)
{
	int utilization;

	dvfs_rwsem_down_read();

	if (!gpu_dvfs_is_enabled())
		OwlRGXGetUtilStats(gpudvfs.psUtil);

	utilization = gpudvfs.psUtil->active;

	dvfs_rwsem_up_read();

	return utilization;
}

static int set_level(int level)
{
	int err;

	if (level < 0 || level >= gpudvfs.num_freqtable_entry)
		return -1;

	if (gpudvfs.preClockSpeedChange) {
		err = gpudvfs.preClockSpeedChange(1);
		if (err)
			return err;
	}

	err = gpudvfs.driver->set_clockspeed(level);

	if (gpudvfs.postClockSpeedChange)
		gpudvfs.postClockSpeedChange(1);

	if (!err)
		gpudvfs.level = level;

	return err;
}

int gpu_dvfs_set_level_range(int minlevel, int maxlevel)
{
	int err = 0, level;

	if (minlevel < 0 ||
		maxlevel > gpudvfs.num_freqtable_entry - 1 ||
		minlevel > maxlevel)
		return -1;

	dvfs_rwsem_down_write();

	gpudvfs.max_level_lock = maxlevel;
	gpudvfs.min_level_lock = minlevel;

	level = gpudvfs.level;
	if (level > maxlevel)
		level = maxlevel;
	else if (level < minlevel)
		level = minlevel;

	if (level != gpudvfs.level)
		err = set_level(level);

	dvfs_rwsem_up_write();

	return err;
}

int gpu_dvfs_get_level(void)
{
	return gpudvfs.level;
}

unsigned long gpu_dvfs_get_clock(int level)
{
	return gpudvfs.dvfs_table[level].freq;
}

int register_gpufreq_dvfs(int level)
{
	int err;
	atomic_set(&gpudvfs.bEnable, 0);

	gpudvfs.num_freqtable_entry = gpudvfs.driver->get_freqtable(&gpudvfs.dvfs_table);
	gpudvfs.min_level_lock = 0;
	gpudvfs.max_level_lock = gpudvfs.num_freqtable_entry - 1;
#if defined(CONFIG_OWL_THERMAL)
	gpudvfs.thermal_level_lock = gpudvfs.num_freqtable_entry - 1;
#endif
	gpudvfs.level = level;

	gpudvfs.preClockSpeedChange  = OwlRGXPreClockSpeedChange;
	gpudvfs.postClockSpeedChange = OwlRGXPostClockSpeedChange;

	/* Initialize the power and clock. */
	err = gpudvfs.driver->init();
	if (err) {
		pr_err("gpu init failed.\n");
		goto err_out;
	}

	gpudvfs.driver->set_clockspeed(gpudvfs.level);

	init_rwsem(&gpudvfs.dvfs_rwsem);
	mutex_init(&gpudvfs.dvfs_enable_mutex);

#if defined(SUPPORT_GPU_DVFS)
	dvfs_init(OwlRGXGetUtilWindow());
#endif

err_out:
	return err;
}

int unregister_gpufreq_dvfs(void)
{
#if defined(SUPPORT_GPU_DVFS)
	dvfs_deinit();
#endif

	gpudvfs.driver->uninit();

	return 0;
}
