#include <linux/fs.h>
#include <linux/rwsem.h>

#include "owlplatform.h"
#include "owldvfs.h"
#include "owlfreq.h"

#define GPU_KOBJ_ATTR(_name, _mode, _show, _store) \
	struct kobj_attribute gpu_attr_##_name = \
	__ATTR(_name, _mode, _show, _store)

typedef enum
{
	GPUFREQ_POLICY_INTERACTIVE = 0,
	GPUFREQ_POLICY_POWERSAVE,
	GPUFREQ_POLICY_PERFORMANCE,
	GPUFREQ_POLICY_BENCHMARK,

	GPUFREQ_NUMBER_OF_POLICY
} GPUFREQ_POLICY;

static struct {
	/* GPU policy */
	int policy;
	/* GPU dvfs sysfs kobject */
	struct kobject *kobj_dvfs;

	struct rw_semaphore rwsem;
} gpuplat = {
	.policy = -1,
	.kobj_dvfs = NULL,
};

#if defined(SUPPORT_GPU_DVFS)
static int set_dvfs_enbled(bool enable)
{
	int err = enable ? -1 : 0;
	if (owl_gpufreq_driver.power_is_enabled()) {
		if (enable)
			err = gpu_dvfs_enable();
		else
			gpu_dvfs_disable();
	}

	return err;
}
#endif

static int transpolicy2dvfslevel(int policy)
{
	int num = gpu_dvfs_get_freqtable(NULL, NULL);
	switch (policy) {
	case GPUFREQ_POLICY_PERFORMANCE:
	case GPUFREQ_POLICY_BENCHMARK:
		return num - 1;
	case GPUFREQ_POLICY_POWERSAVE:
		return 0;
	case GPUFREQ_POLICY_INTERACTIVE:
		return (num > 1) ? 1 : 0;
	default:
		return 0;
	}
}

static int owl_getpolicy(void)
{
	int policy;

	down_read(&gpuplat.rwsem);
	policy = gpuplat.policy;
	up_read(&gpuplat.rwsem);

	return policy;
}

static int owl_setpolicy(int policy)
{
	int err = 0;
	if (policy != gpuplat.policy) {
		int minl = transpolicy2dvfslevel(GPUFREQ_POLICY_POWERSAVE);
		int maxl = transpolicy2dvfslevel(GPUFREQ_POLICY_PERFORMANCE);
#if !defined(SUPPORT_GPU_DVFS)
		int interl = transpolicy2dvfslevel(GPUFREQ_POLICY_INTERACTIVE);
#endif
		down_write(&gpuplat.rwsem);

		switch (policy) {
		case GPUFREQ_POLICY_INTERACTIVE:
#if defined(SUPPORT_GPU_DVFS)
			err  = gpu_dvfs_set_level_range(minl, maxl);
			err |= set_dvfs_enbled(true);
#else
			err = gpu_dvfs_set_level(interl);
#endif
			break;
		case GPUFREQ_POLICY_POWERSAVE:
			err = gpu_dvfs_set_level(minl);
			break;
		case GPUFREQ_POLICY_PERFORMANCE:
		case GPUFREQ_POLICY_BENCHMARK:
			err = gpu_dvfs_set_level(maxl);
			break;
		default:
			break;
		}

		if (!err) {
			gpuplat.policy = policy;
		} else {
			pr_err("GPU: %s: fail to set policy %d\n", __func__, policy);
		}

		up_write(&gpuplat.rwsem);
	}

	return err;
}

static ssize_t show_policy(struct kobject *kobj, struct kobj_attribute *attr, char *buf)
{
	int policy;
	char *policy_str[GPUFREQ_NUMBER_OF_POLICY] = {
		"interactive", "powersave", "performance", "benchmark",
	};

	policy = owl_getpolicy();

	return sprintf(buf, "%d: %s\n", policy, policy_str[policy]);
}

static ssize_t set_policy(struct kobject *kobj, struct kobj_attribute *attr,
						  const char *buf, size_t count)
{
	int policy;

	if (!sscanf(buf, "%d", &policy))
		goto exit_out;

	if (policy < 0 || policy >= GPUFREQ_NUMBER_OF_POLICY)
		goto exit_out;

	owl_setpolicy(policy);

exit_out:
	return count;
}

static ssize_t show_freq(struct kobject *kobj, struct kobj_attribute *attr, char *buf)
{
	return sprintf(buf, "%lu\n", owl_gpu_get_clock_speed());
}

static ssize_t show_dvfs(struct kobject *kobj, struct kobj_attribute *attr,
						 char *buf)
{
	int ret;

#if defined(SUPPORT_GPU_DVFS)
	ret = sprintf(buf, "%d\n", gpu_dvfs_is_enabled());
#else
	ret = sprintf(buf, "%d\n", 0);
#endif

	return ret;
}

static ssize_t set_dvfs(struct kobject *kobj, struct kobj_attribute *attr,
						const char *buf, size_t count)
{
#if defined(SUPPORT_GPU_DVFS)
	int enabled = sysfs_streq("1", buf);
	if (enabled || sysfs_streq("0", buf)) {
		down_write(&gpuplat.rwsem);

		set_dvfs_enbled(enabled);

		up_write(&gpuplat.rwsem);
	}
#endif
	return count;
}

static ssize_t show_dvfs_table(struct kobject *kobj, struct kobj_attribute *attr,
							   char *buf)
{
	size_t size = PAGE_SIZE;
	gpu_dvfs_get_freqtable(buf, &size);
	return size;
}

static ssize_t show_utilization(struct kobject *kobj, struct kobj_attribute *attr,
								char *buf)
{
	return sprintf(buf, "%d\n", gpu_dvfs_get_utilisation());
}

static GPU_KOBJ_ATTR(policy, S_IRUGO|S_IWUGO, show_policy, set_policy);
static GPU_KOBJ_ATTR(freq, S_IRUGO, show_freq, NULL);
static GPU_KOBJ_ATTR(dvfs, S_IRUGO|S_IWUGO, show_dvfs, set_dvfs);
static GPU_KOBJ_ATTR(dvfs_table, S_IRUGO, show_dvfs_table, NULL);
static GPU_KOBJ_ATTR(utilization, S_IRUGO, show_utilization, NULL);

static int gpu_create_sysfs(struct device *dev)
{
	int err = -1;
	gpuplat.kobj_dvfs = kobject_create_and_add("dvfs", &dev->kobj);
	if (gpuplat.kobj_dvfs) {
		err  = sysfs_create_file(gpuplat.kobj_dvfs, &gpu_attr_policy.attr);
		err |= sysfs_create_file(gpuplat.kobj_dvfs, &gpu_attr_freq.attr);
		err |= sysfs_create_file(gpuplat.kobj_dvfs, &gpu_attr_dvfs.attr);
		err |= sysfs_create_file(gpuplat.kobj_dvfs, &gpu_attr_dvfs_table.attr);
		err |= sysfs_create_file(gpuplat.kobj_dvfs, &gpu_attr_utilization.attr);
	}

	return err;
}

static void gpu_remove_sysfs(void)
{
	if (gpuplat.kobj_dvfs) {
		sysfs_remove_file(gpuplat.kobj_dvfs, &gpu_attr_policy.attr);
		sysfs_remove_file(gpuplat.kobj_dvfs, &gpu_attr_freq.attr);
		sysfs_remove_file(gpuplat.kobj_dvfs, &gpu_attr_dvfs.attr);
		sysfs_remove_file(gpuplat.kobj_dvfs, &gpu_attr_dvfs_table.attr);
		sysfs_remove_file(gpuplat.kobj_dvfs, &gpu_attr_utilization.attr);

		kobject_del(gpuplat.kobj_dvfs);
		gpuplat.kobj_dvfs = NULL;
	}
}

int owl_gpu_init(struct device *dev)
{
	int level = transpolicy2dvfslevel(GPUFREQ_POLICY_POWERSAVE);
	if (register_gpufreq_dvfs(level))
		return -1;

	gpuplat.policy = GPUFREQ_POLICY_POWERSAVE;
	owl_setpolicy(GPUFREQ_POLICY_INTERACTIVE);

	init_rwsem(&gpuplat.rwsem);

	if (gpu_create_sysfs(dev))
		dev_err(dev, "Fail to create sysfs.\n");

	return 0;
}

void owl_gpu_uninit(void)
{
	unregister_gpufreq_dvfs();
	gpu_remove_sysfs();

	/* Make sure the clock and power are off. */
	owl_gpu_set_clock_enable(false);
	owl_gpu_set_power_enable(false);
}

int owl_gpu_set_power_enable(bool enabled)
{
	int err;

	down_write(&gpuplat.rwsem);

	err = owl_gpufreq_driver.set_powerstat(enabled);

#if defined(SUPPORT_GPU_DVFS)
	set_dvfs_enbled(enabled);
#endif

	up_write(&gpuplat.rwsem);

	return err;
}

int owl_gpu_set_clock_enable(bool enabled)
{
	int err;

	down_write(&gpuplat.rwsem);

	err = owl_gpufreq_driver.set_clockstat(enabled);

	up_write(&gpuplat.rwsem);

	return err;
}

unsigned long owl_gpu_get_clock_speed(void)
{
	return gpu_dvfs_get_clock(gpu_dvfs_get_level());
}
