/*************************************************************************/ /*!
@File
@Title          System Configuration
@Copyright      Copyright (c) Imagination Technologies Ltd. All Rights Reserved
@Description    System Configuration functions
@License        Dual MIT/GPLv2

The contents of this file are subject to the MIT license as set out below.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

Alternatively, the contents of this file may be used under the terms of
the GNU General Public License Version 2 ("GPL") in which case the provisions
of GPL are applicable instead of those above.

If you wish to allow use of your version of this file only under the terms of
GPL, and not to allow others to use your version of this file under the terms
of the MIT license, indicate your decision by deleting the provisions above
and replace them with the notice and other provisions required by GPL as set
out in the file called "GPL-COPYING" included in this distribution. If you do
not delete the provisions above, a recipient may use your version of this file
under the terms of either the MIT license or GPL.

This License is also included in this distribution in the file called
"MIT-COPYING".

EXCEPT AS OTHERWISE STATED IN A NEGOTIATED AGREEMENT: (A) THE SOFTWARE IS
PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
PURPOSE AND NONINFRINGEMENT; AND (B) IN NO EVENT SHALL THE AUTHORS OR
COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/ /**************************************************************************/

#include <linux/pm_runtime.h>
#include <linux/platform_device.h>
#include <asm/atomic.h>

#include "pvr_debug.h"
#include "osfunc.h"
#include "allocmem.h"
#include "pvrsrv_device.h"
#include "syscommon.h"
#include "power.h"
#include "sysinfo.h"
#include "sysconfig.h"
#include "physheap.h"
#if defined(SUPPORT_ION)
#include PVR_ANDROID_ION_HEADER
#include "ion_support.h"
#endif
#if defined(PVR_USE_DEVICE_TREE)
#include <linux/of_irq.h>
#include <linux/of_address.h>
#endif

#if defined(SUPPORT_SYSTEM_INTERRUPT_HANDLING)
#error "SUPPORT_SYSTEM_INTERRUPT_HANDLING is not supported."
#endif

#include "syslocal.h"
#include "owlplatform.h"

typedef struct _SYS_DATA_
{
	IMG_BOOL bSysClocksOneTimeInit;
	atomic_t sRGXClocksEnabled;
	PVRSRV_DEVICE_NODE *psRGXDeviceNode;
	IMG_UINT32 ui32RGXDeviceID;
} SYS_DATA;

static SYS_DATA gsSysData = {
	.bSysClocksOneTimeInit = IMG_FALSE,
	.sRGXClocksEnabled = {0},
	.psRGXDeviceNode = IMG_NULL,
};

/*
	CPU to Device physcial address translation
*/
static
IMG_VOID OwlSystemCpuPAddrToDevPAddr(IMG_HANDLE hPrivData,
									 IMG_DEV_PHYADDR *psDevPAddr,
									 IMG_CPU_PHYADDR *psCpuPAddr)
{
	PVR_UNREFERENCED_PARAMETER(hPrivData);
	
	psDevPAddr->uiAddr = psCpuPAddr->uiAddr;
}

/*
	Device to CPU physcial address translation
*/
static
IMG_VOID OwlSystemDevPAddrToCpuPAddr(IMG_HANDLE hPrivData,
									 IMG_CPU_PHYADDR *psCpuPAddr,
									 IMG_DEV_PHYADDR *psDevPAddr)				  
{
	PVR_UNREFERENCED_PARAMETER(hPrivData);
	
	psCpuPAddr->uiAddr = psDevPAddr->uiAddr;
}

static IMG_UINT32 OwlGetGpuClockFreq(IMG_HANDLE hSysData)
{
	PVR_UNREFERENCED_PARAMETER(hSysData);

	return (IMG_UINT32)owl_gpu_get_clock_speed();
}

static PVRSRV_ERROR GetRGXDeviceID(SYS_DATA *psSysData)
{
	if (psSysData->psRGXDeviceNode == IMG_NULL)
	{
		PVRSRV_DEVICE_NODE *psDeviceNode;
		PVRSRV_DATA *psPVRSRVData = PVRSRVGetPVRSRVData();
		if (psPVRSRVData == IMG_NULL)
			return PVRSRV_ERROR_INIT_FAILURE;
		psDeviceNode = psPVRSRVData->psDeviceNodeList;
		while (psDeviceNode)
		{
			/* perform any OEM SOC address space customisations here */
			if (psDeviceNode->sDevId.eDeviceType == PVRSRV_DEVICE_TYPE_RGX)
			{
				psSysData->psRGXDeviceNode = psDeviceNode;
				psSysData->ui32RGXDeviceID = psDeviceNode->sDevId.ui32DeviceIndex;
				break;
			}

			/* advance to next device */
			psDeviceNode = psDeviceNode->psNext;
		}
		if (psSysData->psRGXDeviceNode == IMG_NULL)
			return PVRSRV_ERROR_INIT_FAILURE;
	}

	return PVRSRV_OK;
}

int OwlRGXPreClockSpeedChange(int idle)
{
	PVRSRV_ERROR eError;

	if (gsSysData.bSysClocksOneTimeInit == IMG_FALSE)
		return PVRSRV_OK;

	if (gsSysData.psRGXDeviceNode == IMG_NULL)
	{
		eError = GetRGXDeviceID(&gsSysData);
		if (eError != PVRSRV_OK)
			goto err_out;
	}

	eError = PVRSRVDevicePreClockSpeedChange(gsSysData.ui32RGXDeviceID, idle, NULL);

err_out:
	return eError;
}

int OwlRGXPostClockSpeedChange(int idle)
{
	if (gsSysData.bSysClocksOneTimeInit == IMG_FALSE)
		return PVRSRV_OK;

	if (gsSysData.psRGXDeviceNode == IMG_NULL) {
		PVR_DPF((PVR_DBG_ERROR, "OwlRGXPreClockSpeedChange should be called successfully first."));
		return PVRSRV_ERROR_INIT_FAILURE;
	}

	/** Update the clock info for RGX "pfnGetGpuUtilStats". */
	gsRGXTimingInfo.ui32CoreClockSpeed = OwlGetGpuClockFreq(&gsSysData);

	PVRSRVDevicePostClockSpeedChange(gsSysData.ui32RGXDeviceID, idle, NULL);

	return PVRSRV_OK;
}

int OwlRGXGetUtilWindow(IMG_VOID)
{
	/* us -> ms. */
	return RGXFWIF_GPU_STATS_WINDOW_SIZE_US / 1000;
}

int OwlRGXGetUtilStats(struct gpu_util *psStats)
{
	PVRSRV_DEVICE_NODE *psDeviceNode;
	PVRSRV_RGXDEV_INFO *psDevInfo;
	RGXFWIF_GPU_UTIL_STATS sRgxStats;

	if (gsSysData.bSysClocksOneTimeInit == IMG_FALSE) {
		psStats->bValid = 0;
		return -1;
	}

	if (gsSysData.psRGXDeviceNode == IMG_NULL)
		GetRGXDeviceID(&gsSysData);

	psDeviceNode = gsSysData.psRGXDeviceNode;
	psDevInfo = psDeviceNode->pvDevice;

	sRgxStats = psDevInfo->pfnGetGpuUtilStats(psDeviceNode);

	psStats->bValid = (sRgxStats.bValid && !sRgxStats.bIncompleteData);
	psStats->window_size_ms = RGXFWIF_GPU_STATS_WINDOW_SIZE_US / 1000;
	if (psStats->bValid)
	{
		psStats->active  = (sRgxStats.ui32GpuStatActiveHigh + sRgxStats.ui32GpuStatActiveLow) * 100 / RGXFWIF_GPU_STATS_MAX_VALUE_OF_STATE;
		psStats->blocked = sRgxStats.ui32GpuStatBlocked * 100 / RGXFWIF_GPU_STATS_MAX_VALUE_OF_STATE;
		psStats->idle    = 100 - psStats->active - psStats->blocked;
	}

	PVR_DPF((PVR_DBG_MESSAGE, "RGX util: activeH %5u, activeL %5u, blocked %5u, idle %5u",
		     sRgxStats.ui32GpuStatActiveHigh, sRgxStats.ui32GpuStatActiveLow,
		     sRgxStats.ui32GpuStatBlocked, sRgxStats.ui32GpuStatIdle));

	return 0;
}

/******************************************************************************************************
 * Power transiton callback function sequence:
 * preDevicePowerState  -> preSysPowerState -> postSysPowerState -> postDevicePowerState
 * 
 * preDevicePowerState and postDevicePowerState are called int APM.
 * preSysPowerState and postSysPowerState are called by system, like suspend/resume/shutdown, when they
 * are called, preDevicePowerState and postDevicePowerState are called too.
 *****************************************************************************************************/
static PVRSRV_ERROR EnableRGXClocks(SYS_DATA *psSysData)
{
	if (atomic_read(&psSysData->sRGXClocksEnabled) != 0)
		return PVRSRV_OK;

	PVR_DPF((PVR_DBG_MESSAGE, "EnableRGXClocks: Enabling RGX Clocks"));

	/*
	 * Make sure the power(regulator) is enabled, since PVRSRVDevicePrePowerStateKM is called
	 * before PVRSRVSysPrePowerState.
	 */
	if (owl_gpu_set_power_enable(true))
	{
		PVR_DPF((PVR_DBG_ERROR, "EnableRGXClocks: power_enable failed"));
		return PVRSRV_ERROR_UNABLE_TO_ENABLE_CLOCK;
	}

#if defined(CONFIG_PM_RUNTIME)
	{
		/*
		 * pm_runtime_get_sync returns 1 after the module has
		 * been reloaded.
		 */
		int res = pm_runtime_get_sync(&gpsPVRLDMDev->dev);
		if (res < 0)
		{
			PVR_DPF((PVR_DBG_ERROR, "EnableRGXClocks: pm_runtime_get_sync failed (%d)", -res));
			return PVRSRV_ERROR_UNABLE_TO_ENABLE_CLOCK;
		}
	}
#endif

	if (owl_gpu_set_clock_enable(true))
	{
		PVR_DPF((PVR_DBG_ERROR, "EnableRGXClocks: clock_enable failed"));
		return PVRSRV_ERROR_UNABLE_TO_ENABLE_CLOCK;
	}

	psSysData->bSysClocksOneTimeInit = IMG_TRUE;

	/* Indicate that the RGX clocks are enabled */
	atomic_set(&psSysData->sRGXClocksEnabled, 1);

	return PVRSRV_OK;
}

static IMG_VOID DisableRGXClocks(SYS_DATA *psSysData)
{
	if (atomic_read(&psSysData->sRGXClocksEnabled) == 0)
		return;

	PVR_DPF((PVR_DBG_MESSAGE, "DisableRGXClocks: Disabling RGX Clocks"));

#if defined(CONFIG_PM_RUNTIME)
	{
		int res = pm_runtime_put_sync(&gpsPVRLDMDev->dev);
		if (res < 0)
		{
			PVR_DPF((PVR_DBG_ERROR, "DisableRGXClocks: pm_runtime_put_sync failed (%d)", -res));
		}
	}
#endif

	owl_gpu_set_clock_enable(false);

	/* Indicate that the RGX clocks are disabled */
	atomic_set(&psSysData->sRGXClocksEnabled, 0);
}

static PVRSRV_ERROR SysDevicePrePowerState(PVRSRV_DEV_POWER_STATE eNewPowerState,
                                      	   PVRSRV_DEV_POWER_STATE eCurrentPowerState,
									       IMG_BOOL bForced)
{
	PVRSRV_ERROR eError = PVRSRV_OK;
	PVR_UNREFERENCED_PARAMETER(eCurrentPowerState);
	if (eNewPowerState == PVRSRV_DEV_POWER_STATE_ON)
	{
		eError = EnableRGXClocks(&gsSysData);
	}

	return eError;
}

static PVRSRV_ERROR SysDevicePostPowerState(PVRSRV_DEV_POWER_STATE eNewPowerState,
                                            PVRSRV_DEV_POWER_STATE eCurrentPowerState,
									        IMG_BOOL bForced)
{
	PVR_UNREFERENCED_PARAMETER(eCurrentPowerState);
	if (eNewPowerState == PVRSRV_DEV_POWER_STATE_OFF)
	{
		DisableRGXClocks(&gsSysData);
	}

	return PVRSRV_OK;
}

/*
 * Disable power(regulator) enable/disable in linux suspend/resume.
 *
 * Since gpu power domain will be recoveryed to the state recorded in linux suspend_prepare
 * before device resume, and the power domain powered on demands that gpu regulator is enabled.
 */
static PVRSRV_ERROR SysSystemPrePowerState(PVRSRV_SYS_POWER_STATE eNewPowerState)
{
	PVRSRV_ERROR eError = PVRSRV_OK;
#if 0
	if (eNewPowerState == PVRSRV_SYS_POWER_STATE_ON)
	{
		if (owl_gpu_set_power_enable(true))
			eError = PVRSRV_ERROR_UNABLE_TO_ENABLE_CLOCK;
	}
#endif

	return eError;
}

static PVRSRV_ERROR SysSystemPostPowerState(PVRSRV_SYS_POWER_STATE eNewPowerState)
{
#if 0
	if (eNewPowerState == PVRSRV_SYS_POWER_STATE_OFF)
	{
		owl_gpu_set_power_enable(false);
	}
#endif

	return PVRSRV_OK;
}

/*
	SysCreateConfigData
*/
PVRSRV_ERROR SysCreateConfigData(PVRSRV_SYSTEM_CONFIG **ppsSysConfig)
{
	/* Init gpu policy. */
	if (owl_gpu_init(&gpsPVRLDMDev->dev))
	{
		PVR_DPF((PVR_DBG_ERROR, "owl_gpu_init failed."));
		return PVRSRV_ERROR_INVALID_DEVICE;
	}

	/*
	 * Setup RGX specific timing data
	 */
	gsRGXTimingInfo.ui32CoreClockSpeed  = OwlGetGpuClockFreq(&gsSysData);

	/* Save data for this device */
	gsDevices[0].hSysData = (IMG_HANDLE)&gsSysData;

	/* No clock frequency either */
	gsDevices[0].pfnClockFreqGet        = OwlGetGpuClockFreq;

	/* No interrupt handled */
	gsDevices[0].pfnInterruptHandled    = IMG_NULL;

	/* Power management on rgx-owl device */
	gsDevices[0].pfnPrePowerState       = SysDevicePrePowerState;
	gsDevices[0].pfnPostPowerState      = SysDevicePostPowerState;

	/* Power management on owl system (suspend/resume/shutdown) */
	gsSysConfig.pfnSysPrePowerState  = SysSystemPrePowerState;
	gsSysConfig.pfnSysPostPowerState = SysSystemPostPowerState;

#if defined(PVR_USE_DEVICE_TREE)
	{
		struct resource res_irq, res_reg;
		if (!of_irq_to_resource(gpsPVRLDMDev->dev.of_node, 0, &res_irq))
		{
			PVR_DPF((PVR_DBG_ERROR, "of_irq_to_resource error"));
			return PVRSRV_ERROR_INVALID_DEVICE;
		}

		if (of_address_to_resource(gpsPVRLDMDev->dev.of_node, 0, &res_reg))
		{
			PVR_DPF((PVR_DBG_ERROR, "of_address_to_resource error"));
			return PVRSRV_ERROR_INVALID_DEVICE;
		}

		gsDevices[0].ui32IRQ = res_irq.start;
		gsDevices[0].sRegsCpuPBase.uiAddr = res_reg.start;
		gsDevices[0].ui32RegsSize = resource_size(&res_reg);
	}
#endif

	/* Setup other system specific stuff */
#if defined(SUPPORT_ION)
	IonInit(NULL);
#endif

#if defined(CONFIG_PM_RUNTIME)
	pm_runtime_enable(&gpsPVRLDMDev->dev);
#endif

	*ppsSysConfig = &gsSysConfig;

	return PVRSRV_OK;
}

/*
	SysDestroyConfigData
*/
IMG_VOID SysDestroyConfigData(PVRSRV_SYSTEM_CONFIG *psSysConfig)
{
	PVR_UNREFERENCED_PARAMETER(psSysConfig);

#if defined(SUPPORT_ION)
	IonDeinit();
#endif

#if defined(CONFIG_PM_RUNTIME)
	pm_runtime_disable(&gpsPVRLDMDev->dev);
#endif

	owl_gpu_uninit();
}

PVRSRV_ERROR SysAcquireSystemData(IMG_HANDLE hSysData)
{
	PVR_UNREFERENCED_PARAMETER(hSysData);

	return PVRSRV_OK;
}

PVRSRV_ERROR SysReleaseSystemData(IMG_HANDLE hSysData)
{
	PVR_UNREFERENCED_PARAMETER(hSysData);

	return PVRSRV_OK;
}

PVRSRV_ERROR SysDebugInfo(PVRSRV_SYSTEM_CONFIG *psSysConfig, DUMPDEBUG_PRINTF_FUNC *pfnDumpDebugPrintf)
{
	PVR_UNREFERENCED_PARAMETER(psSysConfig);
	PVR_UNREFERENCED_PARAMETER(pfnDumpDebugPrintf);

	return PVRSRV_OK;
}

/******************************************************************************
 End of file (sysconfig.c)
******************************************************************************/
