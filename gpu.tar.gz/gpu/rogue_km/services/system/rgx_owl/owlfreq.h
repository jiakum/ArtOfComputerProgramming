#if !defined(OWL_FREQ_H_)
#define OWL_FREQ_H_

#define RELATION_L 0 /* highest frequency below or at target */
#define RELATION_H 1 /* lowest frequency at or above target */

typedef struct gpufreq_entry {
	unsigned long freq; /* Hz */
	int vol;  /* uV */
	int min_threshold;
	int	max_threshold;
	void *pdata;
} gpufreq_entry_t;

struct gpufreq_driver {
	int (*init)(void);
	void (*uninit)(void);

	int (*clock_is_enabled)(void);
	int (*power_is_enabled)(void);

	int (*set_clockstat)(int enabled);
	int (*set_powerstat)(int enabled);

	int (*get_freqtable)(struct gpufreq_entry **freqtable);

	unsigned long (*get_current_clockspeed)(void);
	unsigned long (*get_clockspeed)(int level);
	int (*set_clockspeed)(int level);

	int (*get_matchlevel)(unsigned long freq, int relation);
	int (*get_matchvollevel)(int vol, int relation);
};

extern struct gpufreq_driver owl_gpufreq_driver;

#endif /* #define OWL_FREQ_H_ */