#if !defined(SYS_LOCAL_H_)
#define SYS_LOCAL_H_

#include <linux/platform_device.h>
#include "img_types.h"

struct gpu_util {
	int bValid;
	u32 window_size_ms;

	u32	active;
	u32	blocked;
	u32	idle;
};

extern struct platform_device *gpsPVRLDMDev;

int OwlRGXPreClockSpeedChange(int idle);
int OwlRGXPostClockSpeedChange(int idle);

int OwlRGXGetUtilWindow(IMG_VOID);
int OwlRGXGetUtilStats(struct gpu_util *psStats);

#endif /* #ifndef SYS_LOCAL_H_ */
